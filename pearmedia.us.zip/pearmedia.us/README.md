# PearMedia

PearMedia is a modern, responsive website designed for media and marketing services. Built with HTML, CSS, JavaScript, and Bootstrap, it offers a clean and professional layout.

## Table of Contents

- [Demo](#demo)
- [Features](#features)
- [Technologies](#technologies)
- [Installation](#installation)
- [Usage](#usage)
- [Contributing](#contributing)
- [License](#license)

## Demo

Visit the live website here: [PearMedia](https://pearmedia.us/)

## Features

- Responsive design for all devices
- Clean and professional layout
- Service showcase
- Client testimonials
- Easy navigation
- Contact information and form

## Technologies

- HTML5
- CSS3
- JavaScript
- Bootstrap 4

## Installation

To run this project locally:

1. Clone the repository:
    ```bash
    git clone https://github.com/yourusername/pearmedia.git
    ```

2. Navigate to the project directory:
    ```bash
    cd pearmedia
    ```

3. Open `index.html` in your web browser.

## Usage

- Use the navigation bar to explore different sections.
- Learn about services and read client testimonials.
- Use the contact form to reach out.

## Contributing

Contributions are welcome! Follow these steps:

1. Fork the repository.
2. Create a new branch (`git checkout -b feature-branch`).
3. Commit your changes (`git commit -m 'Add some feature'`).
4. Push to the branch (`git push origin feature-branch`).
5. Open a Pull Request.

## License

This project is licensed under the MIT License. See the [LICENSE](LICENSE) file for details.
